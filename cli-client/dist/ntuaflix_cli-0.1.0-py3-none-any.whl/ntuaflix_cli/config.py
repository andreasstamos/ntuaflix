API_URL = "http://localhost:8000/ntuaflix_api"
APP_NAME = "ntuaflix-cli"

