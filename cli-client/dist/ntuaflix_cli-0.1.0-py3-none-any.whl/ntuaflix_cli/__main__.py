from . import app

app()

